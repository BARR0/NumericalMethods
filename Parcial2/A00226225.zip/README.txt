Para el caso del archivo B3exp.cpp compilar:

g++ B3exp.cpp

y correr:

./a.out xyvalues.txt


Para el caso del archivo B3pot.cpp compilar:

g++ B3pot.cpp

y correr:

./a.out xyvalues.txt


Los demas:

g++ archivo

y correr:

./a.out
